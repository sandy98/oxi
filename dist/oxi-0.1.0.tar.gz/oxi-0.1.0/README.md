<p align="center">
  <img src="static/img/oxi_1_rounded.jpg" alt="Oxi Logo" width="125px" />
</p>

<h1 align="center">Oxi</h1>

ASGI Full Stack:

* Web Server
* Web App

...and yes, Oxi is a cutie faithful dog!

Coming soon...
