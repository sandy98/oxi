# -*- coding: utf-8 -*-
from . import  __version__ as oxi_version

class OxiApp: ...




