# -*- coding: utf-8 -*-

import asyncio

from . import  __version__ as version

from .server import main

if __name__ == "__main__":
    asyncio.run(main())



