# -*- coding: utf-8 -*-

second = 35

